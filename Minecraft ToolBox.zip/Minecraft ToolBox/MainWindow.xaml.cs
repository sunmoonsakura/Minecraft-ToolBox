﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Minecraft_ToolBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            version.Content += "0.0.0.1";
        }

        private void about_github_MouseDown(object sender, MouseButtonEventArgs e)
        {
            about_github.Foreground = Brushes.Red;
            System.Diagnostics.Process.Start("explorer.exe", "https://github.com/sunmoonsakura");
        }

        private void about_github_MouseMove(object sender, MouseEventArgs e)
        {
            about_github.Foreground = Brushes.Blue;
        }

        private void about_github_MouseLeave(object sender, MouseEventArgs e)
        {
            about_github.Foreground = Brushes.Black;
        }

        private void about_bilibli_MouseDown(object sender, MouseButtonEventArgs e)
        {
            about_bilibli.Foreground = Brushes.Red;
            System.Diagnostics.Process.Start("explorer.exe", "https://space.bilibili.com/9187766");
        }

        private void about_bilibli_MouseLeave(object sender, MouseEventArgs e)
        {
            about_bilibli.Foreground = Brushes.Black;
        }

        private void about_bilibli_MouseMove(object sender, MouseEventArgs e)
        {
            about_bilibli.Foreground = Brushes.Blue;
        }

        private void about_weibo_MouseDown(object sender, MouseButtonEventArgs e)
        {
            about_weibo.Foreground = Brushes.Red;
            System.Diagnostics.Process.Start("explorer.exe", "https://weibo.com/sunmoonsakura");
        }

        private void about_weibo_MouseMove(object sender, MouseEventArgs e)
        {
            about_weibo.Foreground = Brushes.Blue;
        }

        private void about_weibo_MouseLeave(object sender, MouseEventArgs e)
        {
            about_weibo.Foreground = Brushes.Black;
        }

        private void enchant_Click(object sender, RoutedEventArgs e)
        {

            enchant_console.Text = "/give" + " " + player_name.Text + " " + items_name.Text + "{" + "Enchantments:" + "[{id:\"" + enchant_id.Text + "\"" + "," + "lvl:" + enchant_lv.Text + "}]}";

        }

        private void clear_console_Click(object sender, RoutedEventArgs e)
        {
            enchant_console.Text = "";
            enchant_id.Text = "";
            items_name.Text = "";
        }

        private void enchant_lv_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (enchant_lv.Text == "")
                enchant_lv.Text = 1.ToString();
            int number = int.Parse(enchant_lv.Text);
            enchant_lv.Text = number.ToString();
            if (number <= 255)
            {
                return;
            }
            MessageBox.Show("附魔等级不能大于255", "提示：");
            enchant_lv.Text = "255";
        }

        private void enchant_add_Click(object sender, RoutedEventArgs e)
        {
            if (enchant_console.Text == "")
            {
                MessageBox.Show("请先附魔，然后再追加附魔", "提示：");
            }
            else
            {
                enchant_console.SelectionStart = enchant_console.Text.Length - 2;
                enchant_console.Text = enchant_console.Text.Insert(enchant_console.SelectionStart, ",{id:\"" + enchant_id.Text + "\"" + "," + "lvl:" + enchant_lv.Text + "}");
            }
        }

        private void copy_enchant_console_Click(object sender, RoutedEventArgs e)
        {
            this.enchant_console.Focus();
            this.enchant_console.SelectAll();
            this.enchant_console.Copy();
        }

        private void help_MouseDown(object sender, MouseButtonEventArgs e)
        {
            help.Foreground = Brushes.Red;
            System.Diagnostics.Process.Start("explorer.exe", "https://github.com/sunmoonsakura/Minecraft-ToolBox/blob/main/README.md");
        }

        private void help_MouseLeave(object sender, MouseEventArgs e)
        {
            help.Foreground = Brushes.Black;
        }

        private void help_MouseMove(object sender, MouseEventArgs e)
        {
            help.Foreground = Brushes.Blue;
        }

        private void change_log_MouseDown(object sender, MouseButtonEventArgs e)
        {
            change_log.Foreground = Brushes.Red;
            System.Diagnostics.Process.Start("explorer.exe", "https://github.com/sunmoonsakura/Minecraft-ToolBox/blob/main/README.md");
        }

        private void change_log_MouseLeave(object sender, MouseEventArgs e)
        {
            change_log.Foreground = Brushes.Black;
        }

        private void change_log_MouseMove(object sender, MouseEventArgs e)
        {
            change_log.Foreground = Brushes.Blue;
        }
        
    }
}
